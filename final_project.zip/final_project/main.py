from PlaylistChecker import PlaylistChecker


def main():
    my_playlist_checker = PlaylistChecker("playlists.txt")
    my_playlist_checker.main_playlist_checker()


if __name__ == '__main__':
    main()
